

//javascript puro
var boton = document.querySelector(".buttons");

boton.addEventListener("click", cambiarColor);
boton.addEventListener("dblclick",regresaColor);
function cambiarColor(){
   boton.style.background = "red";
   boton.style.color = "white";
}
function regresaColor(){
   boton.style.background = "white";
   boton.style.color = "red";
}


//aprovechamiento de la libreria jquery
$(".buttons").click(function (){
   $(".buttons").css({"background":"red", "color":"white"});
})
$(".buttons").dblclick(function (){
   $(".buttons").css({"background":"white", "color": "red"})
})

